"""Build an editable Blender project and studio render from the named bed parts.

Run from the repository root:
  blender --background --python tools/blender_import_bed.py

The source GLB deliberately keeps each component as a separate named mesh object.
The Quest app uses a different, merged 8-material GLB for draw-call efficiency.
"""
from __future__ import annotations
import argparse
import math
import sys
from pathlib import Path
import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'art' / 'bed' / 'arc_upholstered_bed_editable.glb'
OUTPUT = ROOT / 'art' / 'bed' / 'arc_upholstered_bed.blend'
RENDER = ROOT / 'art' / 'bed' / 'renders' / 'bed_three_quarter.png'
RENDER_DIR = ROOT / 'art' / 'bed' / 'renders'

args_list = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, default=SOURCE)
parser.add_argument('--output', type=Path, default=OUTPUT)
parser.add_argument('--render', type=Path, default=RENDER)
parser.add_argument('--render-dir', type=Path, default=RENDER_DIR)
args = parser.parse_args(args_list)

if not args.source.exists():
    raise FileNotFoundError(f'Editable bed GLB not found: {args.source}')

# Clear the starter scene and create organized model / studio collections.
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for collection in list(bpy.data.collections):
    if collection.name != 'Collection':
        bpy.data.collections.remove(collection)
root = bpy.context.scene.collection
model_collection = bpy.data.collections.new('BED MODEL | editable named parts')
studio_collection = bpy.data.collections.new('STUDIO | render-only setup')
root.children.link(model_collection)
root.children.link(studio_collection)

bpy.ops.import_scene.gltf(filepath=str(args.source))
for obj in list(bpy.context.scene.objects):
    if obj.type == 'MESH':
        for c in list(obj.users_collection): c.objects.unlink(obj)
        model_collection.objects.link(obj)
        obj.name = obj.name.replace('Bed_', '').replace('Headboard_', 'Headboard | ')
        obj['source_asset'] = 'QuestBridgeXR upholstered platform bed'
        if obj.data and obj.data.uv_layers:
            obj.data.uv_layers.active.name = 'Fabric UVs'

# Simple dark studio floor to help inspect the silhouette without changing model materials.
def move_to_collection(obj, collection):
    for c in list(obj.users_collection): c.objects.unlink(obj)
    collection.objects.link(obj)
    return obj

bpy.ops.mesh.primitive_plane_add(size=200, location=(0,-0.035,0))
floor = bpy.context.object; floor.name = 'Studio floor (render only)'; move_to_collection(floor, studio_collection)
mat = bpy.data.materials.new('Studio | midnight slate'); mat.diffuse_color=(.012,.018,.034,1); mat.use_nodes=True
bsdf=mat.node_tree.nodes.get('Principled BSDF'); bsdf.inputs['Base Color'].default_value=(.012,.018,.034,1); bsdf.inputs['Roughness'].default_value=.84
floor.data.materials.append(mat)

def aim(obj, point):
    obj.rotation_euler=(Vector(point)-obj.location).to_track_quat('-Z','Y').to_euler()

def area(name, location, power, color, size, target=(0,.9,0)):
    data=bpy.data.lights.new(name,'AREA'); data.energy=power; data.color=color; data.shape='DISK'; data.size=size
    obj=bpy.data.objects.new(name,data); studio_collection.objects.link(obj); obj.location=location; aim(obj,target); return obj

area('Key | large softbox', (3.8,5.2,4.1), 620, (.78,.84,1.0), 4.2)
area('Fill | cool fabric reveal', (-4.0,3.0,1.0), 420, (.42,.55,1.0), 4.8)
area('Rim | headboard separation', (0.0,4.1,-4.4), 500, (.60,.34,1.0), 3.0)
area('Foot | linen detail', (1.0,2.5,5.0), 250, (1.0,.78,.70), 2.6)

cam_data=bpy.data.cameras.new('Bed studio camera'); cam=bpy.data.objects.new('Bed studio camera',cam_data); studio_collection.objects.link(cam)
cam.location=(4.4,3.1,4.0); aim(cam,(0,.95,0)); cam_data.lens=52
scene=bpy.context.scene; scene.camera=cam
scene.render.engine='CYCLES'; scene.cycles.samples=48
scene.render.resolution_x=1800; scene.render.resolution_y=1350; scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'; scene.render.filepath=str(args.render)
scene.world.use_nodes=True
world_bg=scene.world.node_tree.nodes.get('Background')
if world_bg:
    world_bg.inputs['Color'].default_value=(.018,.022,.040,1.0)
    world_bg.inputs['Strength'].default_value=.34
scene.view_settings.view_transform='AgX'
scene.render.film_transparent=False
scene.camera.data.dof.use_dof=False
scene.render.image_settings.color_mode='RGBA'
scene['asset_notes']='Charcoal channel headboard, padded wraparound rails, fitted cotton sheet, folded graphite duvet and midnight ribbed throw. Dimensions are metres.'

# Leave the editable model selected, while keeping studio objects in their own collection.
bpy.ops.object.select_all(action='DESELECT')
for obj in model_collection.objects: obj.select_set(True)
if model_collection.objects: bpy.context.view_layer.objects.active=model_collection.objects[0]
# Keep four reviewer cameras in the Blender project so the asset opens ready for inspection.
args.output.parent.mkdir(parents=True,exist_ok=True)
args.render.parent.mkdir(parents=True,exist_ok=True)
args.render_dir.mkdir(parents=True,exist_ok=True)
review_views = [
    ('bed_three_quarter', (4.4,3.1,4.0), (0,.95,0), 52),
    ('bed_headboard', (3.5,2.45,-3.25), (0,1.32,-1.28), 58),
    ('bed_side_profile', (4.9,2.35,.15), (0,.82,0), 54),
    ('bed_foot_three_quarter', (-4.0,2.8,2.8), (0,.9,.1), 52),
]
cameras=[]
for name, position, target, lens in review_views:
    data=bpy.data.cameras.new(f'Camera | {name}')
    obj=bpy.data.objects.new(f'Camera | {name}',data)
    studio_collection.objects.link(obj)
    obj.location=position; aim(obj,target); data.lens=lens
    cameras.append((name,obj))
scene.camera=cameras[0][1]
# Textures imported from the GLB are packed into the .blend so it remains self-contained.
bpy.ops.file.pack_all()
bpy.ops.wm.save_as_mainfile(filepath=str(args.output))
for index,(name,camera) in enumerate(cameras):
    scene.camera=camera
    output=args.render if index==0 else args.render_dir/f'{name}.png'
    scene.render.filepath=str(output)
    bpy.ops.render.render(write_still=True)
    print(f'Rendered {name}: {output}')
scene.camera=cameras[0][1]
scene.render.filepath=str(args.render)
bpy.ops.wm.save_as_mainfile(filepath=str(args.output))
print(f'Saved editable Blender project: {args.output}')
